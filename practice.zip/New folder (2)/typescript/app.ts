import { forEachLeadingCommentRange } from "typescript";

console.log("welcome to typescript");

let student: { 
    name: "alka",
    age : 33,
    phone :24356778
}
let studentList :[
    {name:"alka", age :30 ,phone : 2345676},
    {name:" ajay", age: 37,phone: 313131313}

]
studentList.push(student)


for (var index =0;index<=0;index++){
var element = studentList[index];
console.log("name is "+element.name+"age is "+element.age+"phone neumber is "+ element.phone);
}

function GetstudentList(students: any[]){

students.forEach(element => {
    console.log("age"+element.age+"name"+ element.name +"phone"+element.phone)

});
GetstudentList(studentList);
//rest paramenter

function getnumber(...num:number[]){
    num.forEach(element => {
        console.log("number is "+element)
    });
console.log("number is "+element)
    });
}

getnu

}
