"use strict";
exports.__esModule = true;
console.log("welcome to typescript");
var student;
var studentList;
studentList.push(student);
for (var index = 0; index <= 0; index++) {
    var element = studentList[index];
    console.log("name is " + element.name + "age is " + element.age + "phone neumber is " + element.phone);
}
function GetstudentList(students) {
    students.forEach(function (element) {
        console.log("age" + element.age + "name" + element.name + "phone" + element.phone);
    });
    GetstudentList(studentList);
    //rest paramenter
    function getnumber() {
        var num = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            num[_i] = arguments[_i];
        }
        num.forEach(function (element) {
            console.log("number is " + element);
        });
        console.log("number is " + element);
    }
    ;
}
getnu;
