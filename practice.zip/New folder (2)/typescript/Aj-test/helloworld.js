var message = "Hello World";
console.log(message);
