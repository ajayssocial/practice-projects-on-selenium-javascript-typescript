package com.crm.qa.testcases;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.crm.qa.base.TestBase;
import com.crm.qa.pages.LoginPage;
import com.crm.qa.pages.homePage;

public class LoginPageTest extends TestBase {
	LoginPage loginPage ;
	
	public LoginPageTest() {
		super();
	}
	
	@BeforeSuite
	public void dataSetup() {
		preReq();
	}
	
	@BeforeMethod
	public void setUp(){
	initialization(); 
	loginPage = new LoginPage();	
}
	@Test
	public void loginPageTitleTest(){
		String title = loginPage.validatepagetitle();
		Assert.assertEquals(title, "CRMPRO  - CRM software for customer relationship management, sales, and support");
	}
	
	@Test
	public void crmLogoImageTest(){
		boolean flag = loginPage.validateimage();
		Assert.assertTrue(flag);
	}
	@Test
	public void loginTest(){
		homePage homePage = loginPage.Login(prop.getProperty("username"), prop.getProperty("password"));
	}
	
	@AfterMethod
	public void tearDown(){
		//driver.quit();
	}
	
}
