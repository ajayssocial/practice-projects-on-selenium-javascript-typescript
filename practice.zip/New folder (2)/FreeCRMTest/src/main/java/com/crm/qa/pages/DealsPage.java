package com.crm.qa.pages;

public class DealsPage {

}
