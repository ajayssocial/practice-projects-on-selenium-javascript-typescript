package com.selenium.projectselenium;

import java.io.File;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WebDriver {

	public static void main(String[] args) {

		String ProjectLocation = System.getProperty("user.dir");
		System.out.println(File.separator);

		System.setProperty("webdriver.chrome.driver",
				ProjectLocation + File.separator + "drivers" + File.separator + "Chromedriver.exe");

		ChromeDriver driver = new ChromeDriver();

		driver.get("https://www.toolsqa.com/");

		driver.manage().window().maximize();

		driver.findElement(By.linkText("DEMO SITES")).click();
		// nav[@class='navigation']/child::ul

		List<WebElement> mainMenuDemoSites_dd = driver
				.findElements(By.xpath("//nav[@class='navigation']/child::ul/li"));
		

		List<WebElement> demoSites_dd = mainMenuDemoSites_dd.get(6).findElements(By.cssSelector("ul li"));

		for (int i = 0; i < demoSites_dd.size(); i++) {
			String value = demoSites_dd.get(i).findElement(By.cssSelector("span span")).getText();

			System.out.println(value);
             try {
	       Thread.sleep(2000);
          } catch (InterruptedException e) {
	               // TODO Auto-generated catch block
	             e.printStackTrace();
          }
			if (value.equalsIgnoreCase("Automation Practice Form")) {
				 demoSites_dd.get(i).findElement(By.cssSelector("span span")).click();
				 break;
			}
			
			
			//driver.findElement(By.linkText("TUTORIALS")).click();
		
			//List<WebElement> Tuorials1 = driver.findElements(By.xpath("//*[@id=\"primary-menu\"]/li[2]/a/span/span"));
			//List<WebElement> Tutorial2 =Tuorials1.get(11).findElements(By.cssSelector("ul li"));
			

		}
	driver.quit();
	
	
	
	

	}

}



