package second;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {

	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.setProperty("webdriver.chrome.driver", "C:\\Users\\ajays\\chromedriver_win32\\chromedriver.exe");
WebDriver driver = new ChromeDriver();


 driver.get("https://www.crmpro.com/");
 
 driver.manage().window().maximize();
 

 //click on username 
 driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div/input[1]")).sendKeys("alka");
 
 //click on password

 driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div/input[2]")).sendKeys("1234");
//click on login button
 driver.findElement(By.xpath("//*[@id=\"loginForm\"]/div/div/input")).click();
 
 String webtitle = driver.getTitle();
 System.out.println("webtile is "+ webtitle);
 if (webtitle.contentEquals("CRMPRO  - CRM software for customer relationship management, sales, and support")) {
 	System.out.println("Title is 'CRM'--passed");
 } else {
 	System.out.println("Title is not 'CRM'--failed");}
 	
//click on the home button
driver.findElement(By.xpath("//*[@id=\"navbar-collapse\"]/ul/li[1]/a")).click();

//click on the Pricing button
driver.findElement(By.xpath("//*[@id=\"navbar-collapse\"]/ul/li[2]/a")).click();


driver.navigate().back();


driver.quit();


}

}