let x = 5;
let y = 3;
let result = x + y;

console.log('result is '+ result);

let r2 =x-y;
console.log('exponent is '+ r2);

let r3 = x++;
console.log('increment is ' + r3);

console.log(x == y);