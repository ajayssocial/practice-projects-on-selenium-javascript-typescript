var wakeuptime = 7;
var noon = 12;
var lunchtime = 12;
var naptime = lunchtime + 2;
var partytime;
var evening = 18;

// Getting it to show the current time on the page
var showCurrentTime = function()
{
    // display the string on the webpage
    var clock = document.getElementById('clock');
 
    var currentTime = new Date();
 
    var hours = currentTime.getHours();
    var minutes = currentTime.getMinutes();
    var seconds = currentTime.getSeconds();
    var meridian = "AM";
 
    // Set hours
	  if (hours >= noon)
	  {
		  meridian = "PM";
	  }

	  if (hours > noon)
	  {
		  hours = hours - 12;
	  }
 
    // Set Minutes
    if (minutes < 10)
    {
        minutes = "0" + minutes;
    }
 
    // Set Seconds
    if (seconds < 10)
    {
        seconds = "0" + seconds;
    }
 
    // put together the string that displays the time
    var clockTime = hours + ':' + minutes + ':' + seconds + " " + meridian + "!";
 
    clock.innerText = clockTime;
};

// Getting the clock to increment on its own and change out messages and pictures
var updateClock = function() 
{
  var time = new Date().getHours();
  var messageText;
  var image = "https://www.czs.org/custom.czs/files/e3/e3649ee2-8a64-4cf3-a5a0-1d1d38123967.jpg";

  var timeEventJS = document.getElementById("timeEvent");
  var lolcatImageJS = document.getElementById('dolphinImg');
  
  if (time == partytime)
  {
    image = "https://www.dailydot.com/wp-content/uploads/32d/9f/0a4f0db34a3bc6320ef21ff8f6f3b891.jpg";
    messageText = "Let's party!";
  }
  else if (time == wakeuptime)
  {
    image = "https://wakeup-world.com/wp-content/uploads/2011/11/dolphin-lanuguage.jpg";
    messageText = "Wake up!";
  }
  else if (time == lunchtime)
  {
    image = "https://live.staticflickr.com/3149/3287666548_0cec50b04c_z.jpg";
    messageText = "Let's have some lunch!";
  }
  else if (time == naptime)
  {
    image = "https://media.buzzle.com/media/images-en/gallery/fish/1200-145990097-dolphin-resting.jpg";
    messageText = "Sleep tight!";
  }
  else if (time < noon)
  {
    image = "https://static1.squarespace.com/static/5621a997e4b0a49a91cb2538/5ab94eff2b6a28f2b9fa8e61/5aff12f9aa4a99a333600533/1526666000615/JuvenilMales_Courtship.jp";
    messageText = "Good morning!";
  }
  else if (time >= evening)
  {
    image = "https://static1.squarespace.com/static/5621a997e4b0a49a91cb2538/5ab94eff2b6a28f2b9fa8e61/5ab94f34575d1f05f55b2bea/1522093925112/Barbles_BottlenoseFemale_Feeds.jpg";
    messageText = "Good evening!";
  }
  else
  {
    image = "https://static1.squarespace.com/static/5621a997e4b0a49a91cb2538/5ab94eff2b6a28f2b9fa8e61/5ab94f492b6a28f2b9faa639/1522093900225/CrewSearchforDolphins.jpg";
    messageText = "Good afternoon!";
  }

  console.log(messageText); 
  timeEventJS.innerText = messageText;
  dolphinImg.src = image;
  
  showCurrentTime();
};
updateClock();

// Getting the clock to increment once a second
var oneSecond = 1000;
setInterval( updateClock, oneSecond);


// Getting the Party Time Button To Work
var partyButton = document.getElementById("partyTimeButton");

var partyEvent = function()
{
    if (partytime < 0) 
    {
        partytime = new Date().getHours();
        partyTimeButton.innerText = "Party Over!";
        partyTimeButton.style.backgroundColor = "#0A8DAB";
    }
    else
    {
        partytime = -1;
        partyTimeButton.innerText = "Party Time!";
        partyTimeButton.style.backgroundColor = "#222";
    }
};

partyButton.addEventListener("click", partyEvent);
partyEvent(); 


// Activates Wake-Up selector
var wakeUpTimeSelector = document.getElementById("wakeUpTimeSelector");

var wakeUpEvent = function()
{
    wakeuptime = wakeUpTimeSelector.value;
};

wakeUpTimeSelector.addEventListener("change", wakeUpEvent);


// Activates Lunch selector
var lunchTimeSelector =  document.getElementById("lunchTimeSelector");

var lunchEvent = function()
{
    lunchtime = lunchTimeSelector.value;
};

lunchTimeSelector.addEventListener("change", lunchEvent);


// Activates Nap-Time selector
var napTimeSelector =  document.getElementById("napTimeSelector");

var napEvent = function()
{
    naptime = napTimeSelector.value;
};

napTimeSelector.addEventListener("change", napEvent);